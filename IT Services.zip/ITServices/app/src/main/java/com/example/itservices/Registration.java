package com.example.itservices;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Registration extends AppCompatActivity {

    private EditText EdtName, Edtyear, Edtteacher, Edtfeedback, Edtfeedbackcon;
    private Button submit, readfeedback;
    TextView Login;
    ImageView register_arrow;
    private DBHandler dbHandler;

    String emailPattern ="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String contactPattern = "/^[6-9][0-9]{9}$/";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //   final AppCompatActivity activity = Registration.this;

        setContentView(R.layout.activity_registration);

        // initializing all our variables.
        EdtName = (EditText) findViewById(R.id.idEdtName);
        Edtyear = (EditText) findViewById(R.id.idEdtyear);
        Edtteacher = (EditText) findViewById(R.id.idEdtteacher);
        Edtfeedback = (EditText) findViewById(R.id.idEdtfeedback);
        Edtfeedbackcon = (EditText) findViewById(R.id.idEdtfeedbackcon);
        submit = (Button) findViewById(R.id.idsubmit);
        readfeedback = (Button) findViewById((R.id.idreadfeedback));
        register_arrow = findViewById(R.id.register_arrow);
        Login = findViewById(R.id.tvlogin);


        // creating a new dbhandler class
        // and passing our context to it.
        dbHandler = new DBHandler(Registration.this);

        // below line is to add on click listener for our add course button.
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                String Name = EdtName.getText().toString();
                String year = Edtyear.getText().toString();
                String teacher = Edtteacher.getText().toString();
                String feedback = Edtfeedback.getText().toString();
                String feedbackcon = Edtfeedbackcon.getText().toString();

                // validating if the text fields are empty or not.
                if (Name.isEmpty() || year.isEmpty() || teacher.isEmpty() || feedback.isEmpty() || feedbackcon.isEmpty()) {
                    Toast.makeText(Registration.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();

                } else {
                    if (feedback.equals(feedbackcon)) {

                            Boolean checkuser = dbHandler.checkusername(year);

                            if (checkuser == false) {


                                    Boolean insert = dbHandler.adddata(Name, year, teacher, feedback, feedbackcon);
                                    if (insert == true) {
                                        Toast.makeText(Registration.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), login.class);
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(Registration.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                    }

                            } else {
                                Toast.makeText(Registration.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
                            }
                    } else {
                        Toast.makeText(Registration.this, "Passwords not matching", Toast.LENGTH_SHORT).show();
                    }
                }

                // on below line we are calling a method to add feedback
                //  to sqlite data and pass all our values to it.
//                        dbHandler.adddata(Name, year, teacher, feedback,feedbackcon);
//
//                        // after adding the data we are displaying a toast message.
//                        Toast.makeText(Registration.this, "thanks for giving feedback .", Toast.LENGTH_SHORT).show();
                /* Name.setText("");
                year.setText("");
                teacher.setText("");
                feedback.setText("");*/
            }
        });
        readfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity via a intent.
                Intent i = new Intent(Registration.this, viewFeedback.class);
                startActivity(i);
            }
        });
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Registration.this, login.class);
                startActivity(i);

            }
        });
        register_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Registration.this, MainActivity.class);
                startActivity(i);
            }
        });

    }
}


//    public void viewAll(){
//        appCompatTextViewLoginLink.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // opening a new activity via a intent.
//                Cursor res = (Cursor) DBHandler.readregistration();
//                if (res.getCount()==0) {
//                    showMessage("Error","Nothing found");
//                    return;
//                }
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext()){
//                    buffer.append("Id:"+res.getString(0)+"\n");
//                    buffer.append("Passwowd:"+res.getString(1)+"\n");
//                    buffer.append("Confirm_Password:"+res.getString(2)+"\n");
//                    buffer.append("Name:"+res.getString(3)+"\n");
//                    buffer.append("Email:"+res.getString(4)+"\n");
//                }
//                showMessage("Data",buffer.toString());
//                Intent i = new Intent(Registration.this, viewFeedback.class);
//                startActivity(i);
//            }
//
//        });


//}
//    public void showMessage(String title,String Message){
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setCancelable(true);
//        builder.setTitle(title);
//        builder.setMessage(Message);
//        builder.show();
//
//    }
//
//
//}
/**
 * This method is to initialize listeners
 * b
 * //    private void initListeners() {
 * //        submit.setOnClickListener(this);
 * //        appCompatTextViewLoginLink.setOnClickListener(this);
 * //
 * //    }
 * //
 * //    /**
 * //     * This method is to initialize objects to be used
 * //
 * This implemented method is to listen the click on view
 *
 * @param v
 * //
 * This method is to validate the input text fields and post data to SQLite
 */
//    private void initObjects() {
//        inputValidation = new InputValidation(activity);
//        databaseHelper = new DatabaseHelper(activity);
//        user = new User();
//
//    }


/**
 * This implemented method is to listen the click on view
 *
 * @param v
//     */
//    @Override
//    public void onClick(View v) {
//        switch (v.getId()) {
//
//            case R.id.rl_2:
//                postDataToSQLite();
//                break;
//
//            case R.id.appCompatTextViewLoginLink:
//                finish();
//                break;
//        }
//    }

/**
 * This method is to validate the input text fields and post data to SQLite
 */
//    private void postDataToSQLite() {
//        if (!inputValidation.isInputEditTextFilled(textInputEditTextName, textInputLayoutName, getString(R.string.error_message_name))) {
//            return;
//        }
//        if (!inputValidation.isInputEditTextFilled(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
//            return;
//        }
//        if (!inputValidation.isInputEditTextEmail(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
//            return;
//        }
//        if (!inputValidation.isInputEditTextFilled(textInputEditTextPassword, textInputLayoutPassword, getString(R.string.error_message_password))) {
//            return;
//        }
//        if (!inputValidation.isInputEditTextMatches(textInputEditTextPassword, textInputEditTextConfirmPassword,
//                textInputLayoutConfirmPassword, getString(R.string.error_password_match))) {
//            return;
//        }
//
//        if (!databaseHelper.checkUser(textInputEditTextEmail.getText().toString().trim())) {
//
//            user.setName(textInputEditTextName.getText().toString().trim());
//            user.setEmail(textInputEditTextEmail.getText().toString().trim());
//            user.setPassword(textInputEditTextPassword.getText().toString().trim());
//
//            databaseHelper.addUser(user);
//
//            // Snack Bar to show success message that record saved successfully
//
//
//
//            Snackbar.make(nestedScrollView, getString(R.string.success_message), Snackbar.LENGTH_LONG).show();
//            emptyInputEditText();
//
//
//        } else {
//            // Snack Bar to show error message that record already exists
//            Snackbar.make(nestedScrollView, getString(R.string.error_email_exists), Snackbar.LENGTH_LONG).show();
//        }
//
//
//    }
//
//    /**
//     * This method is to empty all input edit text
//     */
//    private void emptyInputEditText() {
//        textInputEditTextName.setText(null);
//        textInputEditTextEmail.setText(null);
//        textInputEditTextPassword.setText(null);
//        textInputEditTextConfirmPassword.setText(null);
//    }
//}
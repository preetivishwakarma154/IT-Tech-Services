package com.example.itservices;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

        private static final String DB_NAME = "feedbackdb";

        // below int is our database version
        private static final int DB_VERSION = 1;

        // below variable is for our table name.
        private static final String TABLE_NAME = "feedback";

        // below variable is for our id column.
        private static final String ID_COL = "id";

        // below variable is for our  name column
        private static final String NAME_COL = "name";

        // below variable id for our year column.
        private static final String YEAR_COL = "year";

        // below variable for our teacher column.
        private static final String TEACHER_COL = "teachername";

        // below variable is for our feedback column.
        private static final String FEEDBACK_COL = "Feedback";
        private static final String FEEDBACKCON_COL = "Feedbackcol";

        // creating a constructor for our database handler.
        public DBHandler(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        // below method is for creating a database by running a sqlite query
        @Override
        public void onCreate(SQLiteDatabase db) {
            // on below line we are creating
            // an sqlite query and we are
            // setting our column names
            // along with their data types.
            String query = "CREATE TABLE " + TABLE_NAME + " ("
                    + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + NAME_COL + " TEXT,"
                    + YEAR_COL + " TEXT,"
                    + TEACHER_COL + " TEXT,"
                    + FEEDBACKCON_COL + " TEXT,"
                    + FEEDBACK_COL + " TEXT)";

            // at last we are calling a exec sql
            // method to execute above sql query
            db.execSQL(query);
        }

        // this method is use to add feedback our sqlite database.
        public Boolean adddata(String Name, String year, String teacher, String feedback, String feedbackcon) {

            // on below line we are creating a variable for
            // our sqlite database and calling writable method
            // as we are writing data in our database.
            SQLiteDatabase db = this.getWritableDatabase();

            // on below line we are creating a
            // variable for content values.
            ContentValues values = new ContentValues();

            // on below line we are passing all values
            // along with its key and value pair.
            values.put(NAME_COL, Name);
            values.put(YEAR_COL, year);
            values.put(TEACHER_COL, teacher);
            values.put(FEEDBACK_COL, feedback);
            values.put(FEEDBACKCON_COL, feedbackcon);

            // after adding all values we are passing
            // content values to our table.
            long result=db.insert(TABLE_NAME, null, values);

            // at last we are closing our
            // database after adding database.
            if (result==-1)
                return false;
            else
                return true;
        }

        // we have created a new method for reading all the feedbacks.
        public ArrayList<Feedbackmodal> readfeedback() {
            // on below line we are creating a
            // database for reading our database.
            SQLiteDatabase db = this.getReadableDatabase();

            // on below line we are creating a cursor with query to read data from database.
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

            // on below line we are creating a new array list.
            ArrayList<Feedbackmodal> ModalArrayList = new ArrayList<>();


            // moving our cursor to first position.
            if (cursor.moveToFirst()) {
                do {
                    // on below line we are adding the data from cursor to our array list.
                    ModalArrayList.add(new Feedbackmodal(cursor.getString(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4)
                            ));
                } while (cursor.moveToNext());
                // moving our cursor to next.
            }
            // at last closing our cursor
            // and returning our array list.
            cursor.close();
            return ModalArrayList;
        }
    public Boolean checkusername(String year){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from "+TABLE_NAME + " where YEAR_COL= ?",new String[]{year});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkusernanepassword(String Email,String Password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor= db.rawQuery(" Select * from "+TABLE_NAME +" where  YEAR_COL = ? and FEEDBACK_COL = ?",new String[]{Email,Password});
        if (cursor.getCount()>0)
            return true;
        else
            return false;
    }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // this method is called to check if the table exists already.
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }
    }



//    public ArrayList<Cursor> getData(String Query){
//        //get writable database
//        SQLiteDatabase sqlDB = this.getWritableDatabase();
//        String[] columns = new String[] { "message" };
//        //an array list of cursor to save two cursors one has results from the query
//        //other cursor stores error message if any errors are triggered
//        ArrayList<Cursor> alc = new ArrayList<Cursor>(2);
//        MatrixCursor Cursor2= new MatrixCursor(columns);
//        alc.add(null);
//        alc.add(null);
//
//        try{
//            String maxQuery = Query ;
//            //execute the query results will be save in Cursor c
//            Cursor c = sqlDB.rawQuery(maxQuery, null);
//
//            //add value to cursor2
//            Cursor2.addRow(new Object[] { "Success" });
//
//            alc.set(1,Cursor2);
//            if (null != c && c.getCount() > 0) {
//
//                alc.set(0,c);
//                c.moveToFirst();
//
//                return alc ;
//            }
//            return alc;
//        } catch(SQLException sqlEx){
//            Log.d("printing exception", sqlEx.getMessage());
//            //if any exceptions are triggered save the error message to cursor an return the arraylist
//            Cursor2.addRow(new Object[] { ""+sqlEx.getMessage() });
//            alc.set(1,Cursor2);
//            return alc;
//        } catch(Exception ex){
//            Log.d("printing exception", ex.getMessage());
//
//            //if any exceptions are triggered save the error message to cursor an return the arraylist
//            Cursor2.addRow(new Object[] { ""+ex.getMessage() });
//            alc.set(1,Cursor2);
//            return alc;
//        }
//    }

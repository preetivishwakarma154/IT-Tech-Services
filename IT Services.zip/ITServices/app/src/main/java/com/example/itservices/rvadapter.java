package com.example.itservices;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
public class rvadapter extends RecyclerView.Adapter<rvadapter.ViewHolder> {


        // variable for our array list and context
        private ArrayList<Feedbackmodal> ModalArrayList;
        private Context context;

        // constructor
        public rvadapter(ArrayList<Feedbackmodal> ModalArrayList, viewFeedback context) {
            this.ModalArrayList = ModalArrayList;
            this.context = context;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // on below line we are inflating our layout
            // file for our recycler view items.
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.feedrv, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            // on below line we are setting data
            // to our views of recycler view item.
            Feedbackmodal modal = ModalArrayList.get(position);
            holder.NameTV.setText(modal.getName());
            holder.feedbackTV.setText(modal.getfeedback());
//            holder.feedbackconTV.setText(modal.getfeedback());
            holder.yearTV.setText(modal.getyear());
            holder.teacherTV.setText(modal.getteacher());
        }

        @Override
        public int getItemCount() {
            // returning the size of our array list
            return ModalArrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            // creating variables for our text views.
            private TextView NameTV, feedbackTV, feedbackconTV, yearTV, teacherTV;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                // initializing our text views
                NameTV = itemView.findViewById(R.id.idName);
                feedbackTV = itemView.findViewById(R.id.idfeedback);
               // feedbackconTV = itemView.findViewById(R.id.idfeedbackcon);
                yearTV = itemView.findViewById(R.id.idyear);
                teacherTV = itemView.findViewById(R.id.idteacher);
            }
        }
    }








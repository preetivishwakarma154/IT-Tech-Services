package com.example.itservices;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;


public class OperatorFragment extends Fragment {
    RelativeLayout B1;
    Intent intent;
    Button button;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_operator, container, false);
        RelativeLayout b = rootView.findViewById(R.id.b1);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator.class);
                startActivity(intent);
            }
        });
        RelativeLayout b1 = rootView.findViewById(R.id.b2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator2.class);
                startActivity(intent);
            }
        });
        RelativeLayout b2 = rootView.findViewById(R.id.b3);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator3.class);
                startActivity(intent);
            }
        });
        RelativeLayout b3 = rootView.findViewById(R.id.b4);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator4.class);
                startActivity(intent);
            }
        });
        RelativeLayout b4 = rootView.findViewById(R.id.b5);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator5.class);
                startActivity(intent);
            }
        });
        RelativeLayout b5 = rootView.findViewById(R.id.b6);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator6.class);
                startActivity(intent);
            }
        });
        RelativeLayout b6 = rootView.findViewById(R.id.b7);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator7.class);
                startActivity(intent);
            }
        });
        RelativeLayout b7 = rootView.findViewById(R.id.b8);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),Operator8.class);
                startActivity(intent);
            }
        });
        return rootView;


    }
}
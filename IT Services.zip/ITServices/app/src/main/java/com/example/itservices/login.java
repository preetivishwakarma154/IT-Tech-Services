package com.example.itservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class login extends AppCompatActivity {
  EditText email,password;
    TextView tv_btn,register;
    ImageView imageView;
    RelativeLayout login_button;
    DBHandler dbHelper;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        imageView = findViewById(R.id.login_arrow);
        tv_btn = findViewById(R.id.tv_btn);
        login_button = findViewById(R.id.rl_2l);
        email = findViewById(R.id.ed_eamil);
        password = findViewById(R.id.ed_pss1);
        register = findViewById(R.id.tv_nu);
        dbHelper = new DBHandler(this);

        tv_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Email = email.getText().toString();
                String Password = password.getText().toString();
                if (Email.isEmpty()||Password.isEmpty())
                    Toast.makeText(login.this, "Please enter all the feilds", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkuserpass = dbHelper.checkusernanepassword(Email,Password);
                    if (checkuserpass == true){
                        Toast.makeText(login.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(login.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }

            }
        });



        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Operator.class);
                startActivity(intent);
            }


        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Registration.class);
                startActivity(intent);
            }


        });


    }

}
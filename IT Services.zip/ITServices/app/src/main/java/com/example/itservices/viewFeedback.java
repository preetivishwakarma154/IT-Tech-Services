package com.example.itservices;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class viewFeedback extends AppCompatActivity {



        // creating variables for our array list,
        // dbhandler, adapter and recycler view.
        private ArrayList<Feedbackmodal> ModalArrayList;
        private DBHandler dbHandler;
        private rvadapter RVAdapter;
        private RecyclerView RV;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_view_feedback);

            // initializing our all variables.
            ModalArrayList = new ArrayList<>();
            dbHandler = new DBHandler(viewFeedback.this);

            // getting our array
            // list from db handler class.
            ModalArrayList = dbHandler.readfeedback();

            // on below line passing our array list to our adapter class.
            RVAdapter = new rvadapter(ModalArrayList, viewFeedback.this);
            RV = (RecyclerView) findViewById(R.id.idRV);

            // setting layout manager for our recycler view.
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(viewFeedback.this, RecyclerView.VERTICAL, false);
            RV.setLayoutManager(linearLayoutManager);

            // setting our adapter to recycler view.
            RV.setAdapter(RVAdapter);
        }

    }

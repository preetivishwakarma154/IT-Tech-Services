package com.example.itservices;

public class Registrationmodal {

    private String name;
    private String email;
    private String number;
    private String password;
    private String confirm_password;
    private int id;

    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setConfirm_password(String confirm_password) {
        this.confirm_password = confirm_password;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Registrationmodal(String name, String email, String number, String password, String confirm_password) {

        this.name = name;
        this.email = email;
        this.number = number;
        this.password = password;
        this.confirm_password = confirm_password;

    }



    public String getEmail() {
        return email;
    }

    public String getNumber() {
        return number;
    }

    public String getPassword() {
        return password;
    }

    public String getConfirm_password() {
        return confirm_password;
    }

    public int getId() {
        return id;
    }




}


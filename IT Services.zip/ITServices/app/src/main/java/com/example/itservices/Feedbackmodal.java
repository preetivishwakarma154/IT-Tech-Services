package com.example.itservices;

public class Feedbackmodal {

        private String Name;
        private String year;
        private String teacher;
        private String feedback;
        private String feedbackcon;

        private int id;

        // creating getter and setter methods
        public String getName() {
            return Name;
        }

        public void setName(String Name) {
            this.Name = Name;
        }

        public String getyear() {
            return year;
        }

        public void setyear(String year) {
            this.year = year;
        }

        public String getteacher() {
            return teacher;
        }

        public void setteacher(String teacher) {
            this.teacher = teacher;
        }

        public String getfeedback() {
            return feedback;
        }

        public void setfeedback(String feedback) {
            this.feedback = feedback;
        }
        public String getfeedbackcon() {
            return feedback;
        }

        public void setFeedbackcon(String feedback) {
            this.feedback = feedback;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        // constructor
        public Feedbackmodal(String Name, String year, String teacher, String feedback) {
            this.Name = Name;
            this.year = year;
            this.teacher = teacher;
            this.feedback = feedback;

        }
    }







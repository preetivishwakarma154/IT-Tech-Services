package com.example.itservices;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;


public class AboutFragment extends Fragment {
    RelativeLayout about,term,policy,contact,rate;
    AlertDialog.Builder builder;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_about, container, false);
         about = rootView.findViewById(R.id.rl_about);
         term = rootView.findViewById(R.id.rl_term);
         policy = rootView.findViewById(R.id.rl_private);
         contact = rootView.findViewById(R.id.rl_contactUs);
         rate = rootView.findViewById(R.id.rl_rate);



         about.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                showAleartDialog("this is about page");
             }
         });
        term.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAleartDialog("this is about page");
            }
        });
        policy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAleartDialog("this is about page");
            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAleartDialog("this is about page");
            }
        });
        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), rating.class);
                startActivity(i);
            }
        });


        return rootView;
    }
    private void showAleartDialog(String message){
        AlertDialog dialog = new AlertDialog.Builder(getActivity()).setTitle("Dialog title").setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).create();
        dialog.show();


    }
}